package pe.gob.sunat.megaproceso.macroproceso.proceso.main.config;

import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.config.MicroserviceConfig;

public class EmprenderConfig extends MicroserviceConfig {

	private static EmprenderConfig config;

	public static EmprenderConfig getConfig() {
		return config;
	}

	public void loadConfig() {
		EmprenderConfig.config = this;
	}
}