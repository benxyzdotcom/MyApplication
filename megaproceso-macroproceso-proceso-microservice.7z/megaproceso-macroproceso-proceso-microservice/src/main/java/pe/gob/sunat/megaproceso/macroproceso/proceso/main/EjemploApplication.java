package pe.gob.sunat.megaproceso.macroproceso.proceso.main;

import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.dropwizard.views.ViewBundle;
import pe.gob.sunat.megaproceso.macroproceso.proceso.main.config.EmprenderConfig;
import pe.gob.sunat.megaproceso.macroproceso.proceso.ws.rest.EmprenderRestService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.SunatApplication;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.ConstraintViolationExceptionMapper;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.GenericExceptionMapper;
import pe.gob.sunat.tecnologia3.arquitectura.framework.microservices.exception.ObjectNotFoundExceptionMapper;

public class EjemploApplication extends SunatApplication<EmprenderConfig> {
	
	@Override
	  public void onRun(EmprenderConfig myConfig, Environment environment) throws Exception {
	    environment.jersey().register(ConstraintViolationExceptionMapper.class);
	    environment.jersey().register(ObjectNotFoundExceptionMapper.class);
	    environment.jersey().register(GenericExceptionMapper.class);
	    environment.jersey().register(EmprenderRestService.class);
	    myConfig.loadConfig();
	}

	
	  @Override
	  public  void onInitialize (Bootstrap<EmprenderConfig> bootstrap) {
	    //Empty implementation for default
		 bootstrap.addBundle(new ViewBundle<EmprenderConfig>());
	  }
	  
	  public static void main(String... params) throws Exception {
		  new EjemploApplication().run(params);
	  }

}
